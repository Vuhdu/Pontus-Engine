#pragma once

namespace Random
{
	float RandomFloat(const float aMin, const float aMax);
	int RandomInt(const int aMin, const int aMax);
}